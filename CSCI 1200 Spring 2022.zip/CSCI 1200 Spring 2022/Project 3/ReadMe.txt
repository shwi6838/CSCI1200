Compile with g++ Project3.cpp Card.cpp User.cpp Enemy.cpp Table.cpp Map.cpp Game.cpp -o Project3
Run with ./Project3

Dependencies
Card.h User.h Enemy.h Table.h Map.h Game.h

Submission By
Author: Shane Wierl
Recitation: 105 – Tiffany Phan
Project 3 CSCI 1300 Spring 22
April 21, 2022

About
A video game based off of Inscription (Steam)
Objective is to build up a card deck and find/upgrade cards
You use the cards in battles and must win to move forward
If you die or give up you start over with a new deck
You move through a map and choose your path (Only move forward)
The path has stops along the way allowing the player to find and upgrade their cards, but also has battles you must move through
To win is to beat the final battle at the end (Theres only 4)

Warning:
My programming environment had lots of issues so game may be unfinished or not work as intended fully
