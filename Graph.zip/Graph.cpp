#include "Graph.hpp"
#include <iostream>
#include <vector>
#include <queue>

using namespace std;

void Graph::addEdge(string v1, string v2)
{
	for(int i=0; i < vertices.size(); i++)
	{
		if(vertices[i]->name == v1)
		{
			for(int j=0; j < vertices.size(); j++)
			{
				if(vertices[j]->name == v2 && i != j)
				{
					adjVertex av;
					av.v = vertices[j];
					vertices[i]->adj.push_back(av);
					// another vetex for edge in the other direction
					adjVertex av2;
					av2.v = vertices[i];
					vertices[j]->adj.push_back(av2);
				}
			}
		}
	}
}

void Graph::addVertex(string n)
{
	bool found = false;
	for(int i=0; i < vertices.size(); i++)
	{
		if(vertices[i]->name == n)
		{
			found = true;
			cout << vertices[i]->name << " found." << endl;
		}
	}
	if(found == false)
	{
		vertex *v = new vertex;
		v->name = n;
		v->distance = 0;
		vertices.push_back(v);
	}
}

void Graph::displayVerticesObj()
{
	// need to loop through the vertices vector
	// you could use regular index loop
	for(vector<vertex*>::iterator itr = vertices.begin(); itr != vertices.end(); itr++)
	{
		auto position = itr - vertices.begin();
		// or auto position = std::distance(vertices.begin(), itr);
		cout << "vertices[" << position << "]: " << *itr << " with key: (" << (*itr)->name << ") " << endl;
		cout << "Its adjacency list contains: ";
		
		// for loop to loop through adj list
		//cout << "(*itr)->adj[0].v->name: " << (*itr)->adj[0].v->name;
		for(int j=0; j < (*itr)->adj.size(); j++)
		{
			cout << " " << (*itr)->adj[j].v->name << endl;
		}
		cout << endl;
	}
}

void Graph::displayEdges()
{
	// for loop - from i=0 to vertices.size()
	// cout << vertices[i]->name << endl
	// inner for loop: from j=0 to vertices[i]->adj.size()
	// 	cout << vertices[i]->adj[j].v->name << endl;
}

void Graph::breadthFirstTraverse(string sourceVertex)
{
	vertex *vertexStart;
	
	// assume sourceVertex = Boulder
	// vertexStart = vertices[2] ----> vertexStart is a pointer to Boulder
	// vertexStart->visited = true; // Boulder's visited = true
	
	// create a queue to keep track of what??? visited vertices!
	// using the STL queue
	queue<vertex*> myqueue;
	
	// going through the adj list of each element in the queue
	// check if the vertex visited
	// if vertex is not visited
		//set the distance of that adj vertex to +1
		//....->visited = true
		// push the adv vertex onto the queue
}