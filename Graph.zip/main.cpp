#include <iostream>
#include <vector>
#include "Graph.hpp"

using namespace std;

int main()
{
	Graph g;
	g.addVertex("Boulder");
	g.addVertex("Denver");
	g.addVertex("Cheyenne");
	
	g.addEdge("Boulder", "Denver");
	g.addEdge("Boulder", "Cheyenne");
	
	g.displayVerticesObj();

	//g.breadthFirstTraverse("Cheyenne");
	
    //g.dijkstraTraverse("Cheyenne");
	
	return 0;
}